//copyright 2025
class const_iterator {
public:

    const_iterator(const iterator& other)
            : the_parent(other.the_parent),
              the_index(other.the_index),
              the_pos(other.the_pos) {}

    const Entry_Type& operator*() const {
        if (*this == the_parent->end()) {
            throw std::invalid_argument("Attempt to de-reference end()");
        }
        return *the_pos;
    }

    const Entry_Type* operator->() const {
        if (*this == the_parent->end()) {
            throw std::invalid_argument("Attempt to de-reference end()");
        }
        return &(*the_pos);
    }

    const_iterator& operator++() {
        ++the_pos;
        advance();
        return *this;
    }

    const_iterator operator++(int) {
        const_iterator temp(*this);
        ++(*this);
        return temp;
    }

    bool operator==(const const_iterator& other) const {
        return the_index == other.the_index && the_pos == other.the_pos;
    }

    bool operator!=(const const_iterator& other) const {
        return !operator==(other);
    }

private:

    void advance() {
        if (the_pos != the_parent->the_buckets[the_index].end()) {
            return;
        } else {
            while (the_index < (the_parent->the_buckets.size() - 1)) {
                the_index++;
                the_pos = the_parent->the_buckets[the_index].begin();
                if (the_pos != the_parent->the_buckets[the_index].end())
                    return;
            }
            the_pos = the_parent->the_buckets[the_index].end();
            return;
        }
    }

    friend class hash_map<Key_Type, Value_Type>;

    const_iterator(const hash_map<Key_Type, Value_Type>* const parent,
                   size_t index,
                   typename std::list<Entry_Type>::const_iterator pos)
            : the_parent(parent),
              the_index(index),
              the_pos(pos) {}

    const hash_map<Key_Type, Value_Type>* const the_parent;
    mutable size_t the_index;
    mutable typename std::list<Entry_Type>::const_iterator the_pos;
};
